//import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable()
export class CalculateZsimpananProvider {

  constructor() {
    console.log('Hello CalculateZsimpananProvider Provider');
  }

  addition(a,b,c,d,e){
    return Number(a) + Number(b) + Number(c) +Number(d) + Number(e);
  }

  multinisab(f,g){
    return Number(f) * 0.025;

  }
}
