import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, Platform, App } from 'ionic-angular';
import { AuthServiceProvider } from '../../providers/auth-service/auth-service';
//import { HomePage } from '../home/home';


@IonicPage()
@Component({
  selector: 'page-main',
  templateUrl: 'main.html',
})
export class MainPage {

  userDetails : any;
  responseData: any;
  userPostData = {"user_id":"","token":""};
  testNav;
  //setRoot: any;

	swtch: string = "calculate";

  constructor(public navCtrl: NavController, public navParams: NavParams, platform: Platform, public authService: AuthServiceProvider, public appCtrl: App) {

    const data = JSON.parse(localStorage.getItem('userData'));
    this.userDetails = data.userData;

    this.userPostData.user_id = this.userDetails.user_id;
    this.userPostData.token = this.userDetails.token;


  }

  goPage1(){
	  this.navCtrl.push('Page1Page');
  }

  goPage2(){
	  this.navCtrl.push('Page2Page');
  }

  goPage3(){
	  this.navCtrl.push('Page3Page');
  }

  goPage5(){
	  this.navCtrl.push('Page5Page');
  }

  goPage6(){
	  this.navCtrl.push('Page6Page');
  }

  goPage7(){
	  this.navCtrl.push('Page7Page');
  }

  logout(){

    localStorage.clear();
    setTimeout(() => this.backToWelcome(), 1000);

  }

  backToWelcome(){
     //console.log("page id is: " + this.navCtrl.getActive().id);
     //const root = this.appCtrl.getRootNav('MainPage');
     //root.popToRoot();

      //console.log(this.appCtrl.getRootNav());

     //this.testNav = this.appCtrl.getRootNavById('n4');
     //this.testNav.setRoot('rootPage');
     this.navCtrl.pop();
  }
}
