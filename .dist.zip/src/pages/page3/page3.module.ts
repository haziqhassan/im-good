import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { Page3Page } from './page3';

@NgModule({
  declarations: [
    Page3Page,
  ],
  imports: [
    IonicPageModule.forChild(Page3Page),
  ],
})
export class Page3PageModule {}
