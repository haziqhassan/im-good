import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, ToastController } from 'ionic-angular';
import { FormGroup, Validators, FormBuilder } from '@angular/forms';

import { Http, Headers, RequestOptions } from '@angular/http';
import 'rxjs/add/operator/map';

@IonicPage()
@Component({
  selector: 'page-register',
  templateUrl: 'register.html',
})
export class RegisterPage {

  public form                   : FormGroup;
  private baseURI               : string  = "http://maipk.haziq.scikomp.com/api/";

  constructor(public navCtrl    : NavController,
              public http       : Http,
              public NP         : NavParams,
              public fb         : FormBuilder,
              public toastCtrl  : ToastController)
  {

              this.form = fb.group({
                   "ic"               : ["", Validators.required],
                   "nama"             : ["", Validators.required],
                   "alamat"           : ["", Validators.required],
                   "poskod"           : ["", Validators.required],
                   "negeri"           : [""],
                   "jenispembayar"    : ["", Validators.required],
                   "kategoripembayar" : ["", Validators.required],
                   "daerah"           : ["", Validators.required],
                   "syarikat"         : [""],
                   "iclama"           : [""],
                   "pekerjaan"        : ["", Validators.required],
                   "telefon"          : ["", Validators.required],
                   "gaji"             : [""],
                   "emel"             : [""],
                   "tarikhbayar"      : ["", Validators.required]
              });
  }



  createEntry(ic, nama, alamat, poskod, negeri, jenispembayar, kategoripembayar, daerah, syarikat, iclama, pekerjaan, telefon, gaji, emel, tarikhbayar)
  {
     let body     : string   = "key=create&ic=" + ic + "&nama=" + nama + "&alamat=" + alamat + "&poskod=" + poskod + "&negeri=" + negeri + "&jenispembayar=" + jenispembayar + "&kategoripembayar=" + kategoripembayar + "&daerah=" + daerah + "&syarikat=" + syarikat + "&iclama=" + iclama + "&pekerjaan=" + pekerjaan + "&telefon=" + telefon + "&gaji=" + gaji + "&emel=" + emel + "&tarikhbayar=" + tarikhbayar,
         type     : string   = "application/x-www-form-urlencoded; charset=UTF-8",
         headers  : any      = new Headers({ 'Content-Type': type}),
         options  : any      = new RequestOptions({ headers: headers }),
         url      : any      = this.baseURI + "manage-data.php";

     this.http.post(url, body, options)
     .subscribe((data) =>
     {


        if(data.status === 200)
        {
           this.sendNotification(`Berjaya, data ${nama} selesai didaftarkan`);
           this.navCtrl.setRoot('MainPage');
           console.log(data);
        }

        else
        {
           this.sendNotification('Pendaftaran gagal, Sila periksa rangkaian internet anda');

        }
     }, error => {
       console.log(error);
     });
  }

  saveEntry()
  {
    let ic            : string = this.form.controls["ic"].value,
        nama          : string = this.form.controls["nama"].value,
        alamat        : string = this.form.controls["alamat"].value,
        poskod        : string = this.form.controls["poskod"].value,
        negeri        : string = this.form.controls["negeri"].value,
        jenispembayar : string = this.form.controls["jenispembayar"].value,
        kategoripembayar  : string = this.form.controls["kategoripembayar"].value,
        daerah        : string = this.form.controls["daerah"].value,
        syarikat      : string = this.form.controls["syarikat"].value,
        iclama        : string = this.form.controls["iclama"].value,
        pekerjaan     : string = this.form.controls["pekerjaan"].value,
        telefon       : string = this.form.controls["telefon"].value,
        gaji          : string = this.form.controls["gaji"].value,
        emel          : string = this.form.controls["emel"].value,
        tarikhbayar   : string = this.form.controls["tarikhbayar"].value;

        this.createEntry(ic, nama, alamat, poskod, negeri, jenispembayar, kategoripembayar, daerah, syarikat, iclama, pekerjaan, telefon, gaji, emel, tarikhbayar);

  }

  sendNotification(message)  : void
  {
     let notification = this.toastCtrl.create({
         message       : message,
         duration      : 3000,
         cssClass      : "toast-container",
         position      : "bottom"
     });
     notification.present();
  }




}
