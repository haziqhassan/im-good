import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { LoginAmPage } from './login-am';

@NgModule({
  declarations: [
    LoginAmPage,
  ],
  imports: [
    IonicPageModule.forChild(LoginAmPage),
  ],
})
export class LoginAmPageModule {}
