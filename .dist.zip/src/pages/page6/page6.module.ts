import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { Page6Page } from './page6';

@NgModule({
  declarations: [
    Page6Page,
  ],
  imports: [
    IonicPageModule.forChild(Page6Page),
  ],
})
export class Page6PageModule {}
