import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { Http } from '@angular/http';
import 'rxjs/add/operator/map';

@IonicPage()
@Component({
  selector: 'page-page1',
  templateUrl: 'page1.html',
})
export class Page1Page {

  public items: any = [];
  public httpdata: any = [];
  public showstoreddata: boolean = false;
  profilepic: boolean = true;

  constructor(public navCtrl: NavController, public navParams: NavParams, public http   : Http) {
    this.oriItems();
  }

  gonext()
  {
    this.navCtrl.push('RegisterPage');
  }

  goedit(param)
  {
    this.navCtrl.push('EditPage', param);
  }

  ionViewDidLoad() {
    this.http.get('http://maipk.haziq.scikomp.com/api/retrieve-data.php')
    .map(res => res.json())
    .subscribe(data =>
    {
       this.items = data;
       this.httpdata = this.items;
       //this.profilepiccheck(this.items.pem_gambar);
       console.log(data);
    }, error => {
      console.log(error);
    });
  }

  /*profilepiccheck(item){

    //this.profilepic = false;
    this.items = this.items.filter((item) => {
      if (item.pem_gambar == ''){
        this.profilepic = false;
      }
    })
  }*/

  oriItems() {

    this.items = this.httpdata;
  }

  getItems(ev) {
    this.oriItems(); // Reset items back to all of the items

    var val = ev.target.value; // set val to the value of the ev target

    // if the value is an empty string don't filter the items
    if (val && val.trim() != '') {

      this.items = this.items.filter((item) => {
        return (item.namaPem.toLowerCase().indexOf(val.toLowerCase()) > -1);
      })
    }

  }

}
