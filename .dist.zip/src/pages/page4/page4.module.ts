import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { Page4Page } from './page4';

@NgModule({
  declarations: [
    Page4Page,
  ],
  imports: [
    IonicPageModule.forChild(Page4Page),
  ],
})
export class Page4PageModule {}
