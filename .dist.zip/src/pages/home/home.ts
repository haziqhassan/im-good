import { Component } from '@angular/core';
import { NavController, ModalController, ToastController } from 'ionic-angular';
import { AuthServiceProvider } from '../../providers/auth-service/auth-service';
//import { MainPage } from '../main/main';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {

  responseData : any;
  userData = {"username": "","password": ""};
  //userData = {"username": "","password": "", "name": "","email": ""};
  passwordType: string = 'password';
  passwordIcon: string = 'eye-off';


  constructor(public navCtrl: NavController, public authService: AuthServiceProvider, public modalCtrl: ModalController, public toastCtrl  : ToastController) {

  }

   goMain()
   {
     this.authService.postData(this.userData,"login").then((result) => {
      this.responseData = result;
        console.log(this.responseData);
      if(this.responseData.userData){
        console.log(this.responseData.userData);
        localStorage.setItem('userData', JSON.stringify(this.responseData));
        this.goMainPage();
      }
      else{
        console.log("Wrong password");
        this.sendNotification("Kad pengenalan atau kata laluan anda salah. Sila cuba lagi.");
      }
    }, (err) => {
      console.log(err);
    });

   }

   goMainPage(){
     this.navCtrl.push('MainPage');
     //let abc = this.modalCtrl.create('MainPage');
     //abc.present();
   }

   sendNotification(message)  : void
   {
      let notification = this.toastCtrl.create({
          message       : message,
          duration      : 3000,
          cssClass      : "toast-container",
          position      : "bottom"
      });
      notification.present();
   }

   hideShowPassword() {
    this.passwordType = this.passwordType === 'text' ? 'password' : 'text';
    this.passwordIcon = this.passwordIcon === 'eye-off' ? 'eye' : 'eye-off';
  }

}
