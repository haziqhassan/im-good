import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { MainAmPage } from './main-am';

@NgModule({
  declarations: [
    MainAmPage,
  ],
  imports: [
    IonicPageModule.forChild(MainAmPage),
  ],
})
export class MainAmPageModule {}
