import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, ToastController } from 'ionic-angular';
import { FormGroup, Validators, FormBuilder } from '@angular/forms';
import { Http, Headers, RequestOptions } from '@angular/http';
import 'rxjs/add/operator/map';

@IonicPage()
@Component({
  selector: 'page-edit',
  templateUrl: 'edit.html',
})
export class EditPage {

  public form    : FormGroup;
  public id          : any;
  public nama        : any;
  public alamat      : any;
  public ic          : any;
  public poskod      : any;
  public negeri      : any;
  //public jenispem    : any;
  //public tarikhdftar : any;
  //public firstbyr    : any;
  public daerah      : any;
  public nosyarikat  : any;
  public ic2         : any;
  public jawatan     : any;
  public telefon     : any;
  public nogaji      : any;
  public emel        : any;
  public gambar      : any;

  public pageTitle   : string;
  private baseURI    : string  = "http://maipk.haziq.scikomp.com/api/";

  constructor(public navCtrl    : NavController,
              public http       : Http,
              public NP         : NavParams,
              public fb         : FormBuilder,
              public toastCtrl  : ToastController) {

                this.form = fb.group({
                  "icd"                  : ["", Validators.required],
                  "namad"                  : ["", Validators.required],
                  "alamatd"                  : ["", Validators.required],
                  "poskodd"                  : ["", Validators.required],
                  "negerid"                  : ["", Validators.required],
                  "daerahd"                  : ["", Validators.required],
                  "nosyarikatd"                  : ["", Validators.required],
                  "ic2d"                  : ["", Validators.required],
                  "jawatand"                  : ["", Validators.required],
                  "telefond"                  : ["", Validators.required],
                  "nogajid"                  : ["", Validators.required],
                  "emeld"                  : ["", Validators.required],
                  "gambard"                  : ["", Validators.required]

                });
  }

  ionViewDidLoad() {

    this.resetFields();
    this.selectEntry(this.NP.get("record"));
    //this.pageTitle     = 'Amend entry';

  }

  selectEntry(item)
  {
     this.id         = item.idPem;
     this.nama       = item.namaPem;
     this.ic         = item.icPem;
     this.alamat     = item.alamatPem;
     this.poskod     = item.pem_poskods1;
     this.negeri = item.pem_negeris1;
     //this.jenispem = item.pem_jnspmbyr;
     //this.tarikhdftar = item.pem_tkhdftar;
     //this.firstbyr = item.pem_firstbyr;
     this.daerah     = item.pem_kodaerah;
     this.nosyarikat = item.pem_nombsykt;
     this.ic2        = item.pem_nombokp2;
     this.jawatan    = item.pem_jawatans;
     this.telefon    = item.pem_telefon1;
     this.nogaji     = item.pem_nombgaji;
     this.emel       = item.pem_emelpbyr;
     this.gambar     = item.pem_gambar;
  }

  resetFields() : void
  {
    this.nama      = "";
    this.ic      = "";
    this.alamat    = "";
    this.poskod    = "";
    this.negeri    = "";
    //this.jenispem    = "";
    //this.tarikhdftar    = "";
    //this.firstbyr    = "";
    this.daerah    = "";
    this.nosyarikat    = "";
    this.ic2    = "";
    this.jawatan    = "";
    this.telefon    = "";
    this.nogaji    = "";
    this.emel    = "";
    this.gambar    = "";
  }

  deleteEntry()
  {
     let name       : string = this.form.controls["namad"].value,
         body       : string = "key=delete&recordID=" + this.id,
         type       : string = "application/x-www-form-urlencoded; charset=UTF-8",
         headers    : any    = new Headers({ 'Content-Type': type}),
         options    : any    = new RequestOptions({ headers: headers }),
         url        : any    = this.baseURI + "manage-data.php";

     this.http.post(url, body, options)
     .subscribe(data =>
     {
        // notify the user if operation is success
    // this will hide the form and message will show up
        if(data.status === 200)
        {
           this.sendNotification(`Profil ${name} selesai dibuang`);
           this.navCtrl.pop();
        }

        // notify the user if operation is fail
        else
        {
           this.sendNotification(`Profil ${name} gagal dibuang`);
        }
     });
  }

  sendNotification(message)  : void
  {
     let notification = this.toastCtrl.create({
         message       : message,
         duration      : 3000,
         cssClass      : "toast-container",
         position      : "bottom"
     });
     notification.present();
  }

}
