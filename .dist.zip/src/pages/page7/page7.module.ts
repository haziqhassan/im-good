import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { Page7Page } from './page7';

@NgModule({
  declarations: [
    Page7Page,
  ],
  imports: [
    IonicPageModule.forChild(Page7Page),
  ],
})
export class Page7PageModule {}
