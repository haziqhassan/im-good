import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import {CalculateZsimpananProvider} from '../../providers/calculate-zsimpanan/calculate-zsimpanan';

@IonicPage()
@Component({
  selector: 'page-zsimpanan',
  templateUrl: 'zsimpanan.html',
})
export class ZsimpananPage {

  result: any;
  nisab: any;
  total_simpanan: any;
  num1: any;
  num2: any;
  num3: any;
  num4: any;
  num5: any;

  public anArray:any=[];
  btn  : any;
  datas: any;
  resultbaru: number=0;
  public values: any;

  constructor(public navCtrl: NavController, public navParams: NavParams, public cz: CalculateZsimpananProvider) {
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad ZsimpananPage');
    this.btn=false;
    this.datas=false;
  }

  add(){
    this.total_simpanan=this.cz.addition(this.num1,this.num2,this.num3,this.num4,this.num5);
    console.log("Total simpanan = ", this.total_simpanan);

    this.result=this.cz.multinisab(this.total_simpanan,this.nisab);
    console.log("Multi Nisab = ", this.result);

  }

goTo(att){
 console.log('this.anArray',this.anArray);
 this.datas=true;
 /*this.values = att.value;
 if(this.datas){
 this.resultbaru=(this.resultbaru + this.values);
 console.log('result baru', this.resultbaru);
 return this.resultbaru;
  }
  else{
    console.log(Error);
  }*/
}

 Adds(){
   this.anArray.push({'value':''});

 }



}
