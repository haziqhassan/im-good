import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ZsimpananPage } from './zsimpanan';

@NgModule({
  declarations: [
    ZsimpananPage,
  ],
  imports: [
    IonicPageModule.forChild(ZsimpananPage),
  ],
})
export class ZsimpananPageModule {}
